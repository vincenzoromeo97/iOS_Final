//
//  GameViewController.swift
//  CarGame
//
//  Created by Romeo Vincenzo G. on 4/19/18.
//  Copyright © 2018 Romeo Vincenzo G. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit
import AVFoundation

class GameViewController: UIViewController {
    
    var audioPlayer = AVAudioPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            //where the audio plays :)
            audioPlayer = try AVAudioPlayer(contentsOf : URL.init(fileURLWithPath: Bundle.main.path(forResource: "sample", ofType: "mp3")!))
            audioPlayer.play()
            
            
        }
        catch{
            
        }
        
        
        
        
        
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = SKScene(fileNamed: "GameMenu") {
                // Set scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Opens the scene
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
            
            view.showsFPS = true
            view.showsNodeCount = true
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any data that have no use.(HELPS FPS)
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
}

