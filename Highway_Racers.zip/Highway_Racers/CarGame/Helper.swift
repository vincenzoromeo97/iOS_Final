//
//  Helper.swift
//  CarGame
//
//  Created by Romeo Vincenzo G. on 4/19/18.
//  Copyright © 2018 Romeo Vincenzo G. All rights reserved.
//

import Foundation
import UIKit

struct ColliderType {
    //car collision helpers
    static let CAR_COLLIDER : UInt32 = 0
    
    static let ITEM_COLLIDER : UInt32 = 1
    static let ITEM_COLLIDER_1 : UInt32 = 2
}

class Helper : NSObject {
    
    func randomBetweenTwoNumbers(firstNumber : CGFloat ,  secondNumber : CGFloat) -> CGFloat{
        return CGFloat(arc4random())/CGFloat(UINT32_MAX) * abs(firstNumber - secondNumber) + min(firstNumber, secondNumber)
    }
}

class Settings {
    static let sharedInstance = Settings()
    
    private init(){
        
    }
    
    var highScore = 0
}
